CIT130 Loops in Java Fall 2026
SCORM 1.2 package

Scoring:
- 9 exercises
- 1 point per exercise
- Maximum score: 9
- Reports cmi.core.score.raw to the LMS / Canvas Gradebook
- Reports cmi.core.score.max = 9
- Saves completion state in cmi.suspend_data

Import the ZIP itself through your Canvas SCORM integration.
