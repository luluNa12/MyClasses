/**
 * Prompt Builder — composes the master instructional-graphic prompt
 * from the current application state.
 *
 * Model-specific templates (role, style notes, closing) live in config.js
 * under MODELS. Quick-start type context further tailors the opening line.
 */

import {
  GRAPHIC_TYPES,
  OPTIONS,
  ICON_PREFERENCES,
  ACCESSIBILITY,
  PEDAGOGICAL,
  MODELS,
  QUICK_STARTS,
  ANIMATION_OPTIONS,
  QUIZ_QUESTION_TYPES
} from './config.js';

/** Look up a label from an options list by value */
function labelOf(list, value) {
  const item = list.find(o => o.value === value);
  return item ? item.label : value || '';
}

/** Look up graphic type object */
function getGraphicType(id) {
  return GRAPHIC_TYPES.find(g => g.id === id) || null;
}

/** Look up model object */
function getModel(id) {
  return MODELS.find(m => m.id === id) || MODELS[MODELS.length - 1];
}

/** Active quick-start template + selected type label */
function getTemplateContext(state) {
  if (!state.templateId) return null;
  const qs = QUICK_STARTS.find(q => q.id === state.templateId);
  if (!qs) return null;
  const typeValue = state[qs.typeKey] || qs.defaultType;
  const typeOpt = (qs.typeOptions || []).find(o => o.value === typeValue);
  return {
    template: qs,
    typeValue,
    typeLabel: typeOpt ? typeOpt.label : typeValue,
    typeFieldLabel: qs.typeLabel
  };
}

/**
 * Role / intent line — prefers quick-start+type tailoring when present,
 * otherwise falls back to the model's default role.
 */
function buildRoleLine(state, model, ctx) {
  if (!ctx) return model.role;

  const { template, typeLabel, typeValue } = ctx;
  const map = {
    classroom: {
      quiz: `${model.role} Design it specifically to support a Quiz: help students prepare for or engage with quiz-style questions and recall.`,
      assignment: `${model.role} Design it specifically to support an Assignment: clarify expectations, steps, or key concepts needed to complete the work.`,
      'interactive-activity': `${model.role} Design it specifically to support an Interactive Activity: guide participation and provide visual anchors for hands-on engagement.`
    },
    lecture: {
      lesson: `${model.role} Design it for a Lesson: support clear explanation and concept development during instruction.`,
      powerpoint: `${model.role} Optimize it for a PowerPoint slide: keep hierarchy clear and text readable when projected.`,
      examples: `${model.role} Focus on Examples: emphasize concrete instances, comparisons, or worked samples that illustrate the concept.`
    },
    training: {
      'faculty-training': `${model.role} Design it for Faculty Training: support professional development for instructors and adult learners.`,
      workshop: `${model.role} Design it for a Workshop: support active, hands-on professional learning and practical application.`
    },
    summary: {
      'study-guide': `${model.role} Design it as a Study Guide: prioritize scannable structure, key terms, and review-friendly layout.`,
      'chapter-summary': `${model.role} Design it as a Chapter Summary: condense essential ideas into a clear hierarchical overview.`
    }
  };

  const byTemplate = map[template.id];
  if (byTemplate && byTemplate[typeValue]) return byTemplate[typeValue];
  return `${model.role} Context: ${template.label} — ${typeLabel}.`;
}

/** Section heading helper */
function sectionHeading(title, model) {
  if (model.sectionStyle === 'numbered') return title;
  return `## ${title}`;
}

/**
 * Build the complete prompt string from state.
 * Structure is shared; framing (role, style notes, closing) is model-specific.
 */
export function buildPrompt(state) {
  const lines = [];
  const model = getModel(state.model);
  const graphic = getGraphicType(state.graphicType);
  const ctx = getTemplateContext(state);

  // --- Role (model default + optional quick-start type tailoring) ---
  lines.push(buildRoleLine(state, model, ctx));
  lines.push('');

  // --- Model style note ---
  if (model.styleNotes) {
    lines.push(`Style guidance for ${model.name}: ${model.styleNotes}`);
    lines.push('');
  }

  // --- Content source ---
  if (state.contentSource === 'file') {
    lines.push(sectionHeading('Content Source', model));
    lines.push('- Source: Uploaded file' + (state.uploadedFileName ? ` (${state.uploadedFileName})` : ''));
    if (state.extractedContent?.trim()) {
      lines.push('- Extracted text context (use as primary content reference):');
      lines.push(state.extractedContent.trim().slice(0, 4000));
    } else if (state.uploadedFileName) {
      lines.push('- Note: Binary file selected; base the graphic on the topic and learning objective below, and any additional instructions.');
    }
    lines.push('');
  }

  // --- Content ---
  lines.push(sectionHeading('Content', model));
  if (state.topic?.trim()) {
    lines.push(`- Topic / Lesson Title: ${state.topic.trim()}`);
  } else {
    lines.push('- Topic / Lesson Title: [Please specify the topic]');
  }

  if (ctx) {
    lines.push(`- Context: ${ctx.template.label} — ${ctx.typeFieldLabel}: ${ctx.typeLabel}`);
  }

  if (state.subjectArea) {
    lines.push(`- Subject Area: ${labelOf(OPTIONS.subjectArea, state.subjectArea)}`);
  }
  if (state.gradeLevel) {
    lines.push(`- Grade / Skill Level: ${labelOf(OPTIONS.gradeLevel, state.gradeLevel)}`);
  }
  if (state.audience?.trim()) {
    lines.push(`- Target Audience: ${state.audience.trim()}`);
  }
  if (state.learningObjective?.trim()) {
    lines.push(`- Learning Objective: By the end of viewing this graphic, the learner will be able to ${state.learningObjective.trim()}`);
  }
  if (state.bloomLevel) {
    lines.push(`- Bloom's Taxonomy Level: ${labelOf(OPTIONS.bloomLevel, state.bloomLevel)}`);
  }
  lines.push('');

  // --- Quiz settings (Classroom Activity → Quiz only) ---
  if (state.templateId === 'classroom' && state.activityType === 'quiz') {
    const count = state.quizQuestionCount || 10;
    const types = (state.quizQuestionTypes || [])
      .map(id => QUIZ_QUESTION_TYPES.find(q => q.id === id)?.label)
      .filter(Boolean);
    const typeList = types.length ? types.join(', ') : 'Multiple Choice';

    lines.push(sectionHeading('Quiz Requirements', model));
    lines.push(`Create exactly ${count} interactive quiz questions using ${typeList} question types. Create a balanced variety of the selected question types throughout the quiz.`);
    lines.push('');
    lines.push('Quiz delivery and interaction rules (required):');
    lines.push('- Create a single self-contained HTML5 file with embedded CSS and JavaScript.');
    lines.push('- Require the student to enter their full name before starting the quiz.');
    lines.push('- Allow only one attempt per question.');
    lines.push('- Lock each question after it is answered.');
    lines.push('- Do not reveal the correct answer if the student answers incorrectly.');
    lines.push('- Display only whether the answer is correct or incorrect.');
    lines.push('- Automatically calculate the total points and percentage score.');
    lines.push("- Display the student's name, total points earned, total possible points, and percentage score at the end of the quiz.");
    lines.push('- Make the quiz responsive, keyboard accessible, and ADA/WCAG 2.1 AA compliant.');
    lines.push('');
  }

  // --- Graphic type ---
  lines.push(sectionHeading('Graphic Type', model));
  if (graphic) {
    lines.push(`- Type: ${graphic.title}`);
    lines.push(`- Purpose: ${graphic.description}`);
    lines.push(`- Design intent: ${graphic.subtitle}`);
  } else {
    lines.push('- Type: [Select a graphic type]');
  }
  lines.push('');

  // --- Visual style ---
  lines.push(sectionHeading('Visual Style & Aesthetic', model));
  lines.push(`- Visual Style: ${labelOf(OPTIONS.visualStyle, state.visualStyle)}`);
  lines.push(`- Tone: ${labelOf(OPTIONS.tone, state.tone)}`);
  lines.push(`- Color Palette: ${labelOf(OPTIONS.colorScheme, state.colorScheme)}`);
  lines.push(`- Complexity / Density: ${labelOf(OPTIONS.complexity, state.complexity)}`);

  if (state.iconPreferences?.length) {
    const iconLabels = state.iconPreferences
      .map(id => ICON_PREFERENCES.find(p => p.id === id)?.label)
      .filter(Boolean);
    if (iconLabels.length) {
      lines.push(`- Icon & Illustration Preference: ${iconLabels.join('; ')}`);
    }
  }
  lines.push('');

  // --- Layout & size ---
  lines.push(sectionHeading('Layout & Image Size', model));
  lines.push(`- Size Preset: ${labelOf(OPTIONS.sizePreset, state.sizePreset)}`);
  lines.push(`- Orientation: ${labelOf(OPTIONS.orientation, state.orientation)}`);
  lines.push(`- Amount of Text: ${labelOf(OPTIONS.amountOfText, state.amountOfText)}`);
  lines.push('');

  // --- Output specs ---
  lines.push(sectionHeading('Output Format', model));
  lines.push(`- File Format: ${labelOf(OPTIONS.fileFormat, state.fileFormat)}`);
  lines.push(`- Resolution: ${labelOf(OPTIONS.resolution, state.resolution)}`);
  lines.push(`- Transparent Background: ${state.transparentBg ? 'Yes' : 'No'}`);
  lines.push(`- Include Safe Margins / Bleed Area: ${state.safeMargins ? 'Yes' : 'No'}`);
  lines.push('');

  // --- Animation (optional) ---
  const anim = ANIMATION_OPTIONS.find(a => a.value === (state.animation || 'none'));
  if (anim && anim.value !== 'none') {
    lines.push(sectionHeading('Animation', model));
    lines.push(`- Animation: ${anim.label}`);
    lines.push(`- Guidance: ${anim.help}`);
    lines.push('- Apply animation only where it supports learning; keep motion purposeful and accessible.');
    const fmt = (state.fileFormat || '').toLowerCase();
    if (fmt === 'interactive-html') {
      lines.push('- Output is Interactive HTML: implement the animation with embedded CSS/JS so it plays in the browser.');
    } else {
      lines.push('- Note: Selected file format is static; describe the intended animation in captions or production notes, but do not assume the image file itself can animate.');
    }
    lines.push('');
  }

  // --- Accessibility ---
  const activeA11y = (state.accessibility || [])
    .map(id => ACCESSIBILITY.find(p => p.id === id)?.label)
    .filter(Boolean);

  if (activeA11y.length) {
    lines.push(sectionHeading('Accessibility', model));
    activeA11y.forEach(label => lines.push(`- ${label}`));
    lines.push('');
  }

  // --- Pedagogical constraints ---
  const activePed = (state.pedagogical || [])
    .map(id => PEDAGOGICAL.find(p => p.id === id)?.label)
    .filter(Boolean);

  if (activePed.length) {
    lines.push(sectionHeading('Pedagogical Constraints', model));
    activePed.forEach(label => lines.push(`- ${label}`));
    lines.push('');
  }

  // --- Extra notes ---
  if (state.extraNotes?.trim()) {
    lines.push(sectionHeading('Additional Instructions', model));
    lines.push(state.extraNotes.trim());
    lines.push('');
  }

  // --- Model-specific generation instructions ---
  lines.push(sectionHeading('Generation Instructions', model));
  lines.push(`Target model: ${model.name} (${model.tagline})`);
  if (Array.isArray(model.closing)) {
    model.closing.forEach(line => lines.push(line));
  } else if (model.closing) {
    lines.push(model.closing);
  } else if (model.promptHint) {
    lines.push(model.promptHint);
  }

  return lines.join('\n').trim();
}

/**
 * Returns a short status summary for the UI (completeness indicator).
 */
export function getPromptStatus(state) {
  const hasTopic = Boolean(state.topic?.trim());
  const hasType = Boolean(state.graphicType);
  const hasObjective = Boolean(state.learningObjective?.trim());

  if (hasTopic && hasType && hasObjective) {
    return { level: 'complete', label: 'Ready to generate' };
  }
  if (hasTopic && hasType) {
    return { level: 'partial', label: 'Add a learning objective for best results' };
  }
  if (hasTopic || hasType) {
    return { level: 'partial', label: 'Select a topic and graphic type' };
  }
  return {
    level: 'empty',
    label: 'Begin by entering a topic and selecting a graphic type'
  };
}
