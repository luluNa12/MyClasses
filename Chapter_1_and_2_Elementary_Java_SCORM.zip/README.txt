CIT 130 Java Interactive Companion — SCORM 1.2

Canvas setup:
1. Upload this ZIP through Canvas SCORM.
2. Choose "Graded Assignment" when Canvas asks how to import it.
3. Set the Canvas assignment points to 20.
4. The package reports a raw score from 0–20.
5. Completion is marked "passed" after all 10 flashcards are completed and all 10 quiz questions are attempted.

Important:
- Do not unzip before uploading to Canvas.
- The activity uses Tailwind CSS from its public CDN, so students need internet access.
