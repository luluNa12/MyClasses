CIT 130 - Introduction to Java Programming
Interactive Lesson Package

Launch file: index.html
SCORM version: SCORM 1.2 style package
Total score: 16 points
- 10 quiz questions, 1 point each
- 6 bonus matching items, 1 point each

This package can also be opened directly in Chrome by opening index.html.
If uploaded to an LMS that supports SCORM 1.2, the lesson attempts to report the raw score out of 16.
